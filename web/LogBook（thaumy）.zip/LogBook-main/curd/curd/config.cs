﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace curd
{
    class logConfig
    {
        public logConfig(string configPath)
        {

        }

        public LogBook GetLogBook()
        {

        }
    }
}
