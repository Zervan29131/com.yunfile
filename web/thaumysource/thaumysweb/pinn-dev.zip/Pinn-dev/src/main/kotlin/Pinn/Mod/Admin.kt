package Pinn.Mod

object Admin {
}