package Pinn

import Pinn.Core.Bot
import Pinn.Core.Config
import Pinn.Interact.*
import Pinn.Mod.*

fun main() {
    /*println(Config.qqUsr)
    println(Config.qqPwd)
    println(Config.dbUsr)
    println(Config.dbPwd)
    println(Config.melonID)
    println(Config.univerID)
    for (id in Config.adminIDs) {
        println(id)
    }*/

    Config
    Bot

    Admin
    Learning
    Mute
    Status

    GetUp
    GoBed
    JbCat
    JbToday
    RuCarousel
    SmartChat
    MiyabiDetect
    Help

    ReLogin
}