﻿using System;

namespace palaCache
{
    public class Class1
    {
    }
}
