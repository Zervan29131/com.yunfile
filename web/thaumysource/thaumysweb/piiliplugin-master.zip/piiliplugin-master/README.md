# piliplugins

This repo is set for plugins of pilipala

## projs

* LightningLink :: make a mark in your post and replace it when display
* Mailssage :: message system for your website(SMTP)
* palaCache :: memory based cache for pilipala to boost post loading
