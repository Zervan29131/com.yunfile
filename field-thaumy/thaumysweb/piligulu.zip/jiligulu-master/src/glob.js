const root_path = "https://www.thaumy.cn"

export default {
    root_path,
}