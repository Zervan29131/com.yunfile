# WaterLibrary

> pilipala内核，基于.NET5平台。

## 开发分支

1.1.7
