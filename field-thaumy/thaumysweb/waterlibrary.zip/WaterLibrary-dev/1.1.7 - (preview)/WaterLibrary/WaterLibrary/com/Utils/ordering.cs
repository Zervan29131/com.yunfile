﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterLibrary.com.Utils
{
    class Ordering
    {
        /// <summary>
        /// 私有构造
        /// </summary>
        private Ordering() { }

        /*public static T GT<T>(T value)
        {

        }*/
    }
}
