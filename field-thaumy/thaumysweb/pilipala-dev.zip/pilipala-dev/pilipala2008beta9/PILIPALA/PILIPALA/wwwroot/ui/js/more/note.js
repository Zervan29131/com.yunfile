﻿let typed = new Typed('#note', {
    strings: ['你好！~~^400', '这里是THAUMY的博客！^300','又一个码农的家', '又一个码农的家.', '又一个码农的家..', '又一个码农的家...'],
    typeSpeed: 100,
    backSpeed: 0,
    smartBackspace: true,
    loop: false
});