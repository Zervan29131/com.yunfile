﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PILIPALA.Event
{
    public class Event
    {
        public delegate void BeforeEvent();

        public class Before
        {
            public static void GetPostEventHandler()
            {
                GetPost += () => { };
                GetPost();
            }

            public static event BeforeEvent DocHead;
            public event BeforeEvent DocBody;
            public event BeforeEvent DocFoot;
            public event BeforeEvent DocComplete;

            public static event BeforeEvent GetPost;
            public static event BeforeEvent CreatePost;
            public event BeforeEvent DeletePost;

            public event BeforeEvent CreateComment;
            public event BeforeEvent DeleteComment;
        }




        public delegate void AfterEvent();


        public class After
        {
            public static void GetPostEventHandler()
            {
                GetPost += () => { };
                GetPost();
            }

            public event AfterEvent DocHead;
            public event AfterEvent DocBody;
            public event AfterEvent DocFoot;
            public event AfterEvent DocComplete;

            public static event AfterEvent GetPost;
            public event AfterEvent CreatePost;
            public event AfterEvent DeletePost;

            public event AfterEvent CreateComment;
            public event AfterEvent DeleteComment;
        }
    }
}
