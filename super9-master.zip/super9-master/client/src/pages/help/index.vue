<template>
  <web-view src='https://mp.weixin.qq.com/s/mG8K-HW01OCWLGiecLwmUg'/>
</template>

<script>
export default {
  name: "index"
}
</script>
