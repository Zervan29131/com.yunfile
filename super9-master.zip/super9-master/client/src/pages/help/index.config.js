export default {
  navigationBarTitleText: '帮助中心'
}
