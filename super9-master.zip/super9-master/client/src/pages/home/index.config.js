export default {
  usingComponents: {
    "van-toast": "@/vant/toast/index"
  }
}
