export default {
  pages: [
    'pages/home/index',
    'pages/help/index'
  ],
  window: {
    "backgroundTextStyle": "light",
    "backgroundColor": "#F3F3F3",
    "navigationBarBackgroundColor": "#F3F3F3",
    "navigationBarTitleText": "短视频水印杀手",
    "navigationBarTextStyle": "black"
  },
  cloud: true,
}
